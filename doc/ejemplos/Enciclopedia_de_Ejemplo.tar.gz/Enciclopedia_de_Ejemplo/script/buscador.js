pcomunes = new Array ();
cresultado = "";
function showcreditos(url)
{
  l=(window.screen.availWidth-520)/2;
  t1=(window.screen.availHeight-340)/2;
  nueva=window.open(url,"ventana","height=340,width=520,alwaysRaised,dependent,scrollbars,top="+t1+",left="+l);
  nueva.focus();
};
function showcolaboradores(url)
{
  l=(window.screen.availWidth-520)/2;
  t1=(window.screen.availHeight-340)/2;
  nueva=window.open(url,"ventana","height=340,width=520,alwaysRaised,dependent,scrollbars,top="+t1+",left="+l);
  nueva.focus();
};
function showautores(url)
{
  l=(window.screen.availWidth-520)/2;
  t1=(window.screen.availHeight-340)/2;
  nueva=window.open(url,"ventana","height=340,width=520,alwaysRaised,dependent,scrollbars,top="+t1+",left="+l);
  nueva.focus();
};
function showayuda(url)
{
  l=(window.screen.availWidth-520)/2;
  t1=(window.screen.availHeight-340)/2;
  nueva=window.open(url,"ventana","height=340,width=520,alwaysRaised,dependent,scrollbars,top="+t1+",left="+l);
  nueva.focus();
};
function actualizar_reproductor_imagen()
{
  if (imagenes.length>0)
    {
	  document.getElementById("miniatura1").src=imagenes [indice_imagen];
	  document.getElementById("aminiatura1").href=imagenes [indice_imagen];
	  document.getElementById("miniatura1").alt=descripciones [indice_imagen];
	 };
  if (imagenes.length>1)
    {
	  document.getElementById("miniatura2").src=imagenes [indice_imagen+1];
	  document.getElementById("aminiatura2").href=imagenes [indice_imagen+1];
	  document.getElementById("miniatura2").alt=descripciones [indice_imagen+1];
	};
  if (imagenes.length>2)
    {
	  document.getElementById("miniatura3").src=imagenes [indice_imagen+2];
	  document.getElementById("aminiatura3").href=imagenes [indice_imagen+2];
	  document.getElementById("miniatura3").alt=descripciones [indice_imagen+2];
	};
  if (imagenes.length) 
    {
      if (imagenes.length>2) 
	    {
		  document.getElementById("mostrando").innerHTML='Mostrando de '+ (indice_imagen+1)+' a '+ (indice_imagen+3) +' de '+ imagenes.length+' im&aacute;genes.';  
		}
	  else
		{
		  document.getElementById("mostrando").innerHTML='Mostrando de 1 a '+ imagenes.length +' de '+ imagenes.length+' im&aacute;genes.';  
		};    
	};  
};
function inicio_imagen()
{
  if (indice_imagen>0) indice_imagen=0;  
  actualizar_reproductor_imagen();   
};
function atras_imagen()
{
  if (indice_imagen>0) indice_imagen--;  
  actualizar_reproductor_imagen();  
};
function adelante_imagen()
{
  if (indice_imagen+2<imagenes.length-1) indice_imagen++;  
  actualizar_reproductor_imagen();  
};
function final_imagen()
{
  if (imagenes.length>3) indice_imagen=imagenes.length-3;
  actualizar_reproductor_imagen();
};
function max()
{
  if (estado)
    {
	  document.getElementById("externo").innerHTML=contenido;
	  estado=false;
	  document.getElementById("max").innerHTML='max';
	}
  else
    {
	  contenido=document.getElementById("externo").innerHTML;
	  document.getElementById("externo").innerHTML=document.getElementById("interno").innerHTML
	  document.getElementById("max").innerHTML='min';
	  estado=true;
	};
};
function show_descrip(descrip)
{
  document.getElementById('descrip').innerHTML='Descripci&oacute;n: '+descrip;
};
function comun(s)
{
  r=false;
  for (e=0;e<pcomunes.length;e++)
    if (s==pcomunes[e])
      r=true;
  return(r); 
};
function depurar(t)
{
  for (i=0;i<t.length;i++)
    { 
	  if ((t[i].length<3) | (comun(t[i])))
	    {
		  t.splice(i,1);
		  i--;
	    } 
	}
};

function mostrar_resultados(lista,indice,cant)
{
  path1=path;
  if (path1=="") { path1="../";} else {path1="";};
  temp=document.getElementById("texto").value;
  salida = "";
  if (!lista.length)
    {
	  cant=1;
	  indice=-1;
	  salida='<br><table width="100%" border="1" cellspacing="0" cellpadding="0"><tr><td bordercolor="#0562A5"><table width="100%" border="0" cellspacing="0" cellpadding="0"><tr><td nowrap="nowrap" bgcolor="#0562A5" class="titulo_ventana">Mostrando de '+(indice+1)+' a '+(indice+cant)+' de '+lista.length+' Resultados de la B&uacute;squeda:</td><td width="100%" bgcolor="#0562A5" class="titulo_ventana"><div align="left" class="desactivado">&nbsp;'+temp+'</div></td></tr><tr><td class="normal"> No hay coincidencias. </td></tr></table></td></tr><tr><td align="right"><a href="javascript:cerrarbusqueda();" class="menu1_link">Cerrar</a></td></tr></table>';	}
  else
    {
	   if (indice+cant>lista.length) cant=lista.length-indice;
	   salida='<br><table width="100%" border="1" cellspacing="0" cellpadding="0"><tr><td bordercolor="#0562A5"><table width="100%" border="0" cellspacing="0" cellpadding="0"><tr><td nowrap="nowrap" bgcolor="#0562A5" class="titulo_ventana">Mostrando de '+(indice+1)+' a '+(indice+cant)+' de '+lista.length+' Resultados de la B&uacute;squeda:</td><td width="100%" bgcolor="#0562A5" class="titulo_ventana"><div align="left" class="desactivado">&nbsp;'+temp+'</div></td></tr><tr><td  colspan="2">';
	   if (indice>0) salida=salida+'<a href="javascript:mostrar_resultados(resultados,'+(indice-10)+',10)" class="menu1_link">Anterior</a>';
       if ((indice>0) & (indice+cant<lista.length)) salida=salida+'<span class="menu1"> - </span>';
	   if (indice+cant<lista.length) salida=salida+'<a href="javascript:mostrar_resultados(resultados,'+(indice+10)+',10)" class="menu1_link">Siguiente</a>';
	   if ((indice>0) | (indice+cant<lista.length)) salida=salida;
	   if (lista.length>10) salida=salida+'<br>';
	   salida=salida+'</td></tr><tr><td colspan="2"><table width="100%" border="0" cellspacing="0" cellpadding="0">'
       for (i=indice;((i<indice+cant) & (i<lista.length));i++)
         {
	      salida=salida+'<tr><td width="0"><img src="'+path1+'imagenes/iconos/articulo.gif" width="32" height="32" hspace="2" vspace="2"></td><td width="100%" valign="middle"><div align="justify" class="menu1_link"><a href="'+lista[i][0]+'" class="menu1_link">'+lista[i][2]+'</a></div><div align="justify"><span class="desactivado">'+lista[i][3]+'</span></div><br></td></tr>';
		  };
		salida=salida+'</table></td></tr></table></td></tr><tr><td align="right"><a href="javascript:cerrarbusqueda();" class="menu1_link">Cerrar</a></td></tr></table>';
	}; 
  if (cresultado=="") cresultado=document.getElementById("resultado").innerHTML;
  document.getElementById("resultado").innerHTML ='';
  document.getElementById("resultado").innerHTML = salida;  
};
function buscar(st)
{
  temp=st.toLowerCase();
  palabras=temp.split(" ");
  //depurar(palabras);
  resultados = new Array();
  if (palabras.length)
    for (i=0; i<t.length; i++)
      {
       	esta=false;
		lc=t[i][0]+t[i][1]+t[i][2]+t[i][3]+t[i][4]+t[i][5]+t[i][6];
		lc.toLowerCase();
		todo=true;
       	for (k=0; k<palabras.length; k++)
	  		if (lc.indexOf(palabras[k])==-1) todo=false;
		if (todo) esta=true;  
        if (esta) 
		{
			rc=t[i][3]; 
			if (path=="") rc = rc.replace('"medias','"../medias');
			resultados[resultados.length] = new Array( 	 path+t[i][0], 
													 	 t[i][1],
													     t[i][2],
													     rc 
													 );
		}
      } 
  mostrar_resultados(resultados,0,10);
};
function cerrarbusqueda()
{
	document.getElementById("resultado").innerHTML = cresultado;
}
t = new Array();
for (i=0;i<3;i++)
  t[i] = new Array();
t[0][0] = ('articulo_2.htm');
t[0][1] = ('articulo uno');
t[0][2] = ('Art&iacute;culo 1');
t[0][3] = ('Resumen del art&iacute;culo 1');
t[0][4] = ('');
t[0][5] = ('artículo 1');
t[0][6] = ('resumen del artículo 1');

t[1][0] = ('articulo_3.htm');
t[1][1] = ('dos');
t[1][2] = ('Articulo 2');
t[1][3] = ('Resumen de articulo 2');
t[1][4] = ('');
t[1][5] = ('articulo 2');
t[1][6] = ('resumen de articulo 2');

t[2][0] = ('articulo_4.htm');
t[2][1] = ('tres');
t[2][2] = ('Articulo 3');
t[2][3] = ('Resumen del articulo 3');
t[2][4] = ('');
t[2][5] = ('articulo 3');
t[2][6] = ('resumen del articulo 3');


